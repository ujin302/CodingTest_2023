import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main {
    public static String[] solutionMap(String[] players, String[] callings) {
        return players;
    }

    public static void main(String[] args) {

    }
}